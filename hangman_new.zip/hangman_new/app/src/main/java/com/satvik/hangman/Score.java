package com.satvik.hangman;


public class Score {
    main_screen mainScreen;

    static int score = 100;
    void update_score_by(int delta)
    {
        score += delta;
    }
    void update_score_correct_letter()
    {
        score += 10;
    }
    void update_score_incorrect_letter()
    {
        score -= 10;
    }
    int return_score()
    {
        return score;
    }
    Score(){
        score = 1000;
    }

}
