package com.satvik.hangman;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Page2 extends AppCompatActivity {
    private Button next;
    private Button next1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);

        next=findViewById(R.id.start);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToMainScreen();
            }
        });
        next1=findViewById(R.id.help);
        next1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToHelp();
            }
        });
    }
    private void moveToMainScreen()
    {
        Intent intent=new Intent(Page2.this,main_screen.class);
        startActivity(intent);
    }
    private void moveToHelp()
    {
        Intent intent=new Intent(Page2.this,Help.class);
        startActivity(intent);
    }
}
