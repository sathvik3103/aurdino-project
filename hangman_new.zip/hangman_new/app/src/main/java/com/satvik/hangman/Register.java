package com.satvik.hangman;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class Register extends AppCompatActivity {
    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    private EditText userName;
    private EditText userPassword;
    private Button register;
    private Button Login;
    private EditText userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        openHelper = new DatabaseHelper(this);
            SetUImethods();

            register.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    db = openHelper.getWritableDatabase();
                    String user_name = userName.getText().toString();
                    String user_email= userEmail.getText().toString();
                    String user_password= userPassword.getText().toString();
                    insertdata(user_name,user_password,user_email);
                    Toast.makeText(getApplicationContext(), "Registered Successfully",Toast.LENGTH_LONG).show();
                }
            });
            Login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    moveToLogin();
                }
            });

    }
    private void SetUImethods()
    {
        userName=findViewById(R.id.etUsername);
        userPassword=findViewById(R.id.etPassword);
        register=findViewById(R.id.btnRegister);
        userEmail=findViewById(R.id.etEmail);
        Login=findViewById(R.id.RLogin);
    }
    public void insertdata(String fname, String pass, String email){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.COL_1, fname);
        contentValues.put(DatabaseHelper.COL_2, email);
        contentValues.put(DatabaseHelper.COL_3, pass);
        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);
    }
    private void moveToLogin()
    {
        Intent intent=new Intent(Register.this,Page1.class);
        startActivity(intent);
    }
}
