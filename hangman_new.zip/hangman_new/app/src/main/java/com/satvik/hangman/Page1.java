package com.satvik.hangman;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Page1 extends AppCompatActivity {
    private Button next;
    private Button Register;
    private EditText Username;
    private EditText Password;
    private TextView info;
    private TextView Email;

    SQLiteDatabase db;
    SQLiteOpenHelper openHelper;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page1);

        Username=findViewById(R.id.etLusername);
        Password=findViewById(R.id.etLpassword);

        openHelper = new DatabaseHelper(this);
        db = openHelper.getReadableDatabase();
        Email=findViewById(R.id.Email);


        Register=findViewById(R.id.LRegister);
        next=findViewById(R.id.login);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = Username.getText().toString();
                String pass = Password.getText().toString();
                String email= Email.getText().toString();
                cursor = db.rawQuery(" SELECT * FROM " + DatabaseHelper.TABLE_NAME + " WHERE " + DatabaseHelper.COL_1 + " =? AND " + DatabaseHelper.COL_2 + " =? AND "+DatabaseHelper.COL_3+"=?", new String[]{name,email,pass});
                if(cursor != null){
                    if(cursor.getCount() > 0){
                        cursor.moveToNext();
                        Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_LONG).show();
                        movetoPage2();
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToRegister();
            }
        });
    }

    private void moveToRegister()
    {

        Intent intent=new Intent(Page1.this,Register.class);
        startActivity(intent);
    }
    private void movetoPage2()
    {
        Intent intent =new Intent(Page1.this,Page2.class);
        startActivity(intent);
    }
}
